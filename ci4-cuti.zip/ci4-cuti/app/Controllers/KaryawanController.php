<?php

namespace App\Controllers;

use App\Models\KaryawanModel;

class KaryawanController extends BaseController
{
    protected $karyawanModel;

    public function __construct()
    {
        $this->karyawanModel = new KaryawanModel();
    }

    // Menampilkan daftar karyawan
    public function index()
    {
        $data['karyawan'] = $this->karyawanModel->findAll();
        return view('karyawan/index', $data);
    }

    // Menampilkan form tambah karyawan
    public function create()
    {
        return view('karyawan/create');
    }

    // Menyimpan data karyawan baru
    public function store()
    {
        $this->karyawanModel->save([
            'nama_awal' => $this->request->getPost('nama_awal'),
            'nama_akhir' => $this->request->getPost('nama_akhir'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'departemen' => $this->request->getPost('departemen'),
            'alamat' => $this->request->getPost('alamat'),
            'kota' => $this->request->getPost('kota'),
            'negara' => $this->request->getPost('negara'),
            'nomer_telfon' => $this->request->getPost('nomer_telfon'),
            'status' => $this->request->getPost('status'),
            'tanggal_daftar' => date('Y-m-d')
        ]);
        return redirect()->to('/karyawan');
    }

    // Menampilkan form edit karyawan
    public function editProfil()
{

    // Ambil data karyawan yang sedang login dari session
    $id_karyawan = session()->get('id_karyawan');
    
    // Ambil data karyawan dari database
    $karyawan = $this->karyawanModel->find($id_karyawan);

    if (!$karyawan) {
        return redirect()->to('/karyawan/profil')->with('error', 'Data karyawan tidak ditemukan.');
    }

    // Tampilkan view edit profil dengan data karyawan
    return view('karyawan/edit_profil', ['karyawan' => $karyawan]);
}


    // Menyimpan perubahan data karyawan
    public function update($id)
    {
        $this->karyawanModel->update($id, [
            'nama_awal' => $this->request->getPost('nama_awal'),
            'nama_akhir' => $this->request->getPost('nama_akhir'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'departemen' => $this->request->getPost('departemen'),
            'alamat' => $this->request->getPost('alamat'),
            'kota' => $this->request->getPost('kota'),
            'negara' => $this->request->getPost('negara'),
            'nomer_telfon' => $this->request->getPost('nomer_telfon'),
            'status' => $this->request->getPost('status'),
            'tanggal_daftar' => $this->request->getPost('tanggal_daftar')
        ]);
        return redirect()->to('/karyawan');
    }

    public function gantiPassword()
    {
        return view('karyawan/gantipassword');
    }

    // Menghapus data karyawan
    public function delete($id)
    {
        $this->karyawanModel->delete($id);
        return redirect()->to('/karyawan');
    }

    // Menampilkan profil karyawan yang sedang login
    public function profil()
{
    // Cek apakah session id_karyawan ada
    if (!session()->has('id_karyawan')) {
        return redirect()->to('/login_karyawan')->with('error', 'Silakan login terlebih dahulu.');
    }

    // Ambil id karyawan dari session
    $id_karyawan = session()->get('id_karyawan');

    // Ambil data karyawan berdasarkan id
    $data['karyawan'] = $this->karyawanModel->getKaryawanWithDepartemen($id_karyawan);


    return view('karyawan/profil', $data);
}

    public function updatePassword()
    {
        // Cek apakah session karyawan ada
        if (!session()->has('id_karyawan')) {
            return redirect()->to('/login_karyawan')->with('error', 'Silakan login terlebih dahulu.');
        }

        // Ambil id karyawan dari session
        $id_karyawan = session()->get('karyawan')['id_karyawan'];

        // Validasi input
        $rules = [
            'password_lama' => 'required',
            'password_baru' => 'required|min_length[8]',
            'konfirmasi_password' => 'required|matches[password_baru]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        // Ambil data dari form
        $password_lama = $this->request->getPost('password_lama');
        $password_baru = $this->request->getPost('password_baru');

        // Ambil data karyawan
        $karyawan = $this->karyawanModel->find($id_karyawan);

        // Verifikasi password lama
        if (!password_verify($password_lama, $karyawan['password'])) {
            return redirect()->back()->with('error', 'Password lama salah!');
        }

        // Update password baru
        $this->karyawanModel->update($id_karyawan, [
            'password' => password_hash($password_baru, PASSWORD_DEFAULT),
        ]);

        return redirect()->to('/profil')->with('success', 'Password berhasil diubah!');
    }

    // Menyimpan perubahan profil karyawan
    public function updateProfil()
{
    // Periksa apakah session 'karyawan' ada
    if (!session()->has('karyawan')) {
        return redirect()->to('/login_karyawan')->with('error', 'Silakan login terlebih dahulu.');
    }

    // Ambil id karyawan dari session
    $id_karyawan = session()->get('karyawan')['id_karyawan'];

    // Validasi input
    if (!$this->validate($this->karyawanModel->getValidationRules())) {
        return redirect()->back()->withInput()->with('validation', $this->validator);
    }

    // Ambil data dari form
    $data = [
        'nama_awal'     => $this->request->getPost('nama_awal'),
        'nama_akhir'    => $this->request->getPost('nama_akhir'),
        'email'         => $this->request->getPost('email'),
        'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
        'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
        'departemen'    => $this->request->getPost('departemen'),
        'alamat'        => $this->request->getPost('alamat'),
        'kota'          => $this->request->getPost('kota'),
        'negara'        => $this->request->getPost('negara'),
        'nomer_telfon'  => $this->request->getPost('nomer_telfon'),
        'status'        => $this->request->getPost('status'),
    ];

    // Update data karyawan
    $this->karyawanModel->update($id_karyawan, $data);

    return redirect()->to('/karyawan/profil')->with('message', 'Profil berhasil diperbarui.');
}

    public function someOtherMethod()
{
    // Periksa apakah session 'karyawan' ada dan memiliki 'id_karyawan'
    $id_karyawan = session()->get('karyawan')['id_karyawan'] ?? null;
    if (!$id_karyawan) {
        return redirect()->to('/login_karyawan')->with('error', 'Silakan login terlebih dahulu.');
    }

    // Lanjutkan dengan logika method
}
}
