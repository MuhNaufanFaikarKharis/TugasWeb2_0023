<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Laporan Cuti</title>
    <!-- SB Admin Bootstrap CSS -->
    <link href="<?= base_url('sb-admin2/vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?= base_url('sb-admin2/css/sb-admin-2.min.css') ?>" rel="stylesheet">
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3"><?= session()->get('username') ?? 'Admin'; ?></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="<?= base_url('dashboard') ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">Menu</div>

            <!-- Nav Item - Departemen -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('departemen') ?>">
                    <i class="fas fa-fw fa-building"></i>
                    <span>Departemen</span>
                </a>
            </li>

            <!-- Nav Item - Tipe Cuti -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('cuti') ?>">
                    <i class="fas fa-fw fa-calendar-alt"></i>
                    <span>Tipe Cuti</span>
                </a>
            </li>

            <!-- Nav Item - Karyawan -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('karyawan') ?>">
                    <i class="fas fa-fw fa-users"></i>
                    <span>Karyawan</span>
                </a>
            </li>

            <!-- Nav Item - Manajemen Cuti -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('laporancuti') ?>">
                    <i class="fas fa-fw fa-tasks"></i>
                    <span>Manajemen Cuti</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Logout -->
            <li class="nav-item">
                <a class="nav-link" href="/logout">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                                    <?= session()->get('username') ?? 'Admin'; ?>
                                </span>
                                <img class="img-profile rounded-circle" src="https://via.placeholder.com/60" alt="Profile">
                            </a>
                        </li>
                    </ul>
                </nav>

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Daftar Laporan Cuti</h1>

                    <!-- Table Laporan Cuti -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Laporan Cuti</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID Detail Cuti</th>
                                            <th>ID Karyawan</th>
                                            <th>ID Cuti</th>
                                            <th>Tipe Cuti</th>
                                            <th>Tanggal Cuti</th>
                                            <th>Tanggal Selesai Cuti</th>
                                            <th>Alasan Cuti</th>
                                            <th>Tanggal Pengajuan</th>
                                            <th>Pesan Admin</th>
                                            <th>Tanggal Konfirmasi Admin</th>
                                            <th>Status</th>
                                            <th>Telah Dibaca Admin</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($laporan as $item): ?>
                                            <tr>
                                                <td><?= $item['id_detail_cuti']; ?></td>
                                                <td><?= $item['id_karyawan']; ?></td>
                                                <td><?= $item['id_cuti']; ?></td>
                                                <td><?= $item['tipe_cuti']; ?></td>
                                                <td><?= $item['tanggal_cuti']; ?></td>
                                                <td><?= $item['tanggal_selesai_cuti']; ?></td>
                                                <td><?= $item['alasan_cuti']; ?></td>
                                                <td><?= $item['tanggal_pengajuan']; ?></td>
                                                <td><?= $item['pesan_admin']; ?></td>
                                                <td><?= $item['tanggal_konfirmasi_admin']; ?></td>
                                                <td><?= $item['status']; ?></td>
                                                <td><?= $item['telah_dibaca_admin'] ? 'Ya' : 'Tidak'; ?></td>
                                                <td>
                                                    <a href="<?= site_url('laporancuti/export-pdf/' . $item['id_detail_cuti']); ?>" class="btn btn-sm btn-success">Export PDF</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- SB Admin Bootstrap JS -->
    <script src="<?= base_url('sb-admin2/vendor/jquery/jquery.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/js/sb-admin-2.min.js') ?>"></script>
</body>

</html>