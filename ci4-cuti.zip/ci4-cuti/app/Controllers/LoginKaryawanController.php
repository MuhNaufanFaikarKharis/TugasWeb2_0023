<?php

namespace App\Controllers;

use App\Models\LoginKaryawanModel;
use App\Models\DepartemenModel;

class LoginKaryawanController extends BaseController
{
    // Show login page
    public function index()
    {
        return view('login_karyawan/login');
    }

    // Show registration page
    public function registerPage()
    {
        $departemenModel = new DepartemenModel();
        $departemen = $departemenModel->findAll();

        return view('login_karyawan/register', ['departemen' => $departemen]);
    }

    // Handle registration form submission
    public function register()
    {
        $validation = \Config\Services::validation();

        // Validate input
        if (!$this->validate([
            'nama_awal' => 'required|min_length[3]',
            'nama_akhir' => 'required|min_length[3]',
            'email' => 'required|valid_email|is_unique[karyawan.email]',
            'password' => 'required|min_length[6]',
            'password_confirm' => 'required|matches[password]',
            'jenis_kelamin' => 'required|in_list[L,P]',
            'tanggal_lahir' => 'required|valid_date',
            'departemen' => 'required|integer',
        ])) {
            return redirect()->back()->withInput()->with('error', $validation->listErrors());
        }

        $model = new LoginKaryawanModel();
        $passwordHash = password_hash($this->request->getPost('password'), PASSWORD_DEFAULT);

        // Save new user to the database
        $model->save([
            'nama_awal' => $this->request->getPost('nama_awal'),
            'nama_akhir' => $this->request->getPost('nama_akhir'),
            'email' => $this->request->getPost('email'),
            'password' => $passwordHash,
            'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'departemen' => $this->request->getPost('departemen'),
            'alamat' => $this->request->getPost('alamat'),
            'kota' => $this->request->getPost('kota'),
            'negara' => $this->request->getPost('negara'),
            'nomer_telfon' => $this->request->getPost('nomer_telfon'),
            'status' => 'aktif', // Example default status
            'tanggal_daftar' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to('/login_karyawan')->with('success', 'Registration successful, please login.');
    }

    // Handle login form submission
    public function doLogin()
    {
        $session = session();
        $model = new LoginKaryawanModel();

        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $user = $model->where('email', $email)->first();

        if ($user) {
            if (password_verify($password, $user['password'])) {
                $session->set([
                    'id_karyawan' => $user['id_karyawan'],
                    'nama_awal' => $user['nama_awal'],
                    'isLoggedIn' => true,
                ]);
                return redirect()->to('/dashboard');
            } else {
                return redirect()->back()->with('error', 'Password incorrect.');
            }
        } else {
            return redirect()->back()->with('error', 'Email not found.');
        }
    }

    // Logout
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login_karyawan');
    }
}
