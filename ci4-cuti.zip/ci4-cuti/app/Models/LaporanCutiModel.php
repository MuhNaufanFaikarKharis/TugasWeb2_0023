<?php

namespace App\Models;

use CodeIgniter\Model;

class LaporanCutiModel extends Model
{
    protected $table = 'detail_cuti'; // Nama tabel di database
    protected $primaryKey = 'id_detail_cuti'; // Primary key
    protected $allowedFields = [
        'id_detail_cuti',
        'id_karyawan',
        'id_cuti',
        'tipe_cuti',
        'tanggal_cuti',
        'tanggal_selesai_cuti',
        'alasan_cuti',
        'tanggal_pengajuan',
        'pesan_admin',
        'tanggal_konfirmasi_admin',
        'status',
        'telah_dibaca_admin'
    ];

    // Menambahkan method untuk mengambil data laporan cuti beserta informasi karyawan dan tipe cuti
    public function getLaporanById($id)
    {
        return $this->select('detail_cuti.*, karyawan.nama_awal, karyawan.nama_akhir, cuti.tipe_cuti')
                    ->join('karyawan', 'karyawan.id_karyawan = detail_cuti.id_karyawan')
                    ->join('cuti', 'cuti.id_cuti = detail_cuti.id_cuti')
                    ->where('id_detail_cuti', $id)
                    ->first();
    }
}
