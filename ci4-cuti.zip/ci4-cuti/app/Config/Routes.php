<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->group('', ['namespace' => 'App\Controllers'], function ($routes) {
    // Rute Login dan Logout Admin
    $routes->get('/', 'LoginController::index'); // Halaman login admin
    $routes->get('/login', 'LoginController::index'); // Halaman login admin
    $routes->post('/login/authenticate', 'LoginController::authenticateAdmin'); // Proses login admin
    $routes->get('/logout', 'LoginController::logout'); // Logout admin
    $routes->get('/register', 'LoginController::register'); // Halaman register admin
    $routes->post('/register/store', 'LoginController::storeAdmin'); // Proses register admin

    // Rute Login dan Logout Karyawan
    $routes->get('/login_karyawan', 'LoginController::loginKaryawan'); // Halaman login karyawan
    $routes->post('/login_karyawan/doLogin', 'LoginController::authenticateKaryawan'); // Proses login karyawan
    $routes->get('/login_karyawan/register', 'LoginController::registerKaryawan'); // Halaman register karyawan
    $routes->post('/login_karyawan/register', 'LoginController::storeKaryawan'); // Proses register karyawan
    $routes->get('/login_karyawan/logout', 'LoginController::logout'); // Logout karyawan

    // Rute Dashboard
    $routes->get('/dashboard', 'DashboardAdminController::index'); // Halaman dashboard

    // Rute Cuti
    $routes->get('/cuti', 'CutiController::index'); // Halaman daftar cuti
    $routes->get('/cuti/create', 'CutiController::create'); // Halaman form cuti
    $routes->post('/cuti/store', 'CutiController::store'); // Simpan data cuti
    $routes->get('/cuti/edit/(:num)', 'CutiController::edit/$1'); // Edit data cuti
    $routes->post('/cuti/update/(:num)', 'CutiController::update/$1'); // Update data cuti
    $routes->get('/cuti/delete/(:num)', 'CutiController::delete/$1'); // Hapus data cuti
    $routes->get('/cuti/export-pdf', 'CutiController::exportPdf'); // Export PDF untuk daftar cuti

    // Rute Laporan Cuti
    $routes->get('/laporancuti', 'LaporanCutiController::index'); // Halaman laporan cuti
    $routes->get('/laporancuti/(:num)', 'LaporanCutiController::detail/$1'); // Detail laporan cuti
    $routes->get('/laporancuti/export-pdf/(:num)', 'LaporanCutiController::exportPdf/$1'); // Export PDF laporan cuti

    // Rute Rekap Cuti
    $routes->get('/rekap-cuti', 'RekapCutiController::index'); // Halaman rekap cuti
    $routes->get('/rekap-cuti/export-pdf', 'RekapCutiController::exportPdf'); // Export rekap cuti ke PDF

    // Rute Karyawan
    $routes->get('/karyawan', 'KaryawanController::index'); // Halaman daftar karyawan
    $routes->get('/karyawan/create', 'KaryawanController::create'); // Tambah data karyawan
    $routes->post('/karyawan/store', 'KaryawanController::store'); // Simpan data karyawan
    $routes->get('/karyawan/edit/(:num)', 'KaryawanController::edit/$1'); // Edit data karyawan
    $routes->post('/karyawan/update/(:num)', 'KaryawanController::update/$1'); // Update data karyawan
    $routes->get('/karyawan/delete/(:num)', 'KaryawanController::delete/$1'); // Hapus data karyawan

    // Rute Profil Karyawan
    $routes->get('/karyawan/profil', 'KaryawanController::profil'); // Profil karyawan
    $routes->get('/karyawan/editProfil', 'KaryawanController::editProfil'); // Edit profil karyawan
    $routes->post('/karyawan/updateProfil', 'KaryawanController::updateProfil'); // Update profil karyawan
    $routes->get('karyawan/ganti-password', 'KaryawanController::gantiPassword'); // Halaman ganti password
    $routes->post('/karyawan/updatePassword', 'KaryawanController::updatePassword'); // Update password

    // Rute Departemen
    $routes->get('/departemen', 'DepartemenController::index');
    $routes->get('/departemen/create', 'DepartemenController::create');
    $routes->post('/departemen/store', 'DepartemenController::store');
    $routes->get('/departemen/edit/(:num)', 'DepartemenController::edit/$1');
    $routes->post('/departemen/update/(:num)', 'DepartemenController::update/$1');
    $routes->get('/departemen/delete/(:num)', 'DepartemenController::delete/$1');
});

