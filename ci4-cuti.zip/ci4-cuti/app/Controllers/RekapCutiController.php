<?php
namespace App\Controllers;

use App\Models\DetailCutiModel;
use App\Models\KaryawanModel; // Tambahkan ini
use Dompdf\Dompdf;
use Dompdf\Options;

class RekapCutiController extends BaseController
{
    protected $detailCutiModel;
    protected $karyawanModel;

    public function __construct()
    {
        $this->detailCutiModel = new DetailCutiModel();
        $this->karyawanModel = new KaryawanModel(); // Tambahkan ini
    }

    public function index()
    {
        // Periksa apakah session 'id_karyawan' ada
        if (!session()->has('id_karyawan')) {
            return redirect()->to('/login_karyawan')->with('error', 'Silakan login terlebih dahulu.');
        }

        // Ambil id_karyawan dari session
        $idKaryawan = session()->get('id_karyawan');

        // Ambil data karyawan dari database
        $karyawan = $this->karyawanModel->find($idKaryawan);

        if (!$karyawan) {
            return redirect()->to('/login_karyawan')->with('error', 'Data karyawan tidak ditemukan.');
        }

        // Ambil data detail cuti berdasarkan id_karyawan
        $rekapCuti = $this->detailCutiModel
            ->where('id_karyawan', $idKaryawan)
            ->findAll();

        // Kirim data ke view
        return view('karyawan/rekap', [
            'rekapCuti' => $rekapCuti,
            'karyawan' => $karyawan
        ]);
    }

    public function exportPdf()
    {
        // Periksa apakah session 'id_karyawan' ada
        if (!session()->has('id_karyawan')) {
            return redirect()->to('/login_karyawan')->with('error', 'Silakan login terlebih dahulu.');
        }

        // Ambil id_karyawan dari session
        $idKaryawan = session()->get('id_karyawan');

        // Ambil data karyawan dari database
        $karyawan = $this->karyawanModel->find($idKaryawan);

        if (!$karyawan) {
            return redirect()->to('/login_karyawan')->with('error', 'Data karyawan tidak ditemukan.');
        }

        // Ambil data rekap cuti berdasarkan id_karyawan
        $rekapCuti = $this->detailCutiModel
            ->where('id_karyawan', $idKaryawan)
            ->findAll();

        // Load view 'karyawan/rekappdf' dan kirim data ke view
        $html = view('karyawan/rekappdf', [
            'rekapCuti' => $rekapCuti,
            'karyawan' => $karyawan
        ]);

        // Initialize DomPDF
        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);

        // (Optional) Set paper size
        $dompdf->setPaper('A4', 'portrait');

        // Render PDF (first pass)
        $dompdf->render();

        // Output the generated PDF to Browser
        $dompdf->stream('rekap-cuti.pdf', ['Attachment' => 0]);
    }
}