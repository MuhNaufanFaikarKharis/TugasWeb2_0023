<?php

namespace App\Models;

use CodeIgniter\Model;

class KaryawanModel extends Model
{
    protected $table = 'karyawan';
    protected $primaryKey = 'id_karyawan';
    protected $allowedFields = [
        'nama_awal', 'nama_akhir', 'email', 'password', 'jenis_kelamin', 
        'tanggal_lahir', 'departemen', 'alamat', 'kota', 'negara', 
        'nomer_telfon', 'status', 'tanggal_daftar'
    ];

    // Validasi input
    protected $validationRules = [
        'nama_awal'     => 'required|max_length[100]',
        'nama_akhir'    => 'required|max_length[100]',
        'email'         => 'required|valid_email|max_length[255]',
        'jenis_kelamin' => 'required|in_list[L,P]',
        'tanggal_lahir' => 'required|valid_date',
        'departemen'    => 'permit_empty|max_length[100]', // Ubah dari integer ke string
        'alamat'        => 'permit_empty|max_length[65535]',
        'kota'          => 'permit_empty|max_length[100]',
        'negara'        => 'permit_empty|max_length[100]',
        'nomer_telfon'  => 'permit_empty|max_length[20]', // Tambah batas maksimal
        'status'        => 'required|in_list[aktif,nonaktif]',
    ];

    protected $validationMessages = [
        'nama_awal' => [
            'required'   => 'Nama awal wajib diisi.',
            'max_length' => 'Nama awal maksimal 100 karakter.',
        ],
        'nama_akhir' => [
            'required'   => 'Nama akhir wajib diisi.',
            'max_length' => 'Nama akhir maksimal 100 karakter.',
        ],
        'email' => [
            'required'    => 'Email wajib diisi.',
            'valid_email' => 'Email tidak valid.',
            'max_length'  => 'Email maksimal 255 karakter.',
        ],
        'jenis_kelamin' => [
            'required' => 'Jenis kelamin wajib diisi.',
            'in_list'  => 'Jenis kelamin harus L (Laki-laki) atau P (Perempuan).',
        ],
        'tanggal_lahir' => [
            'required'    => 'Tanggal lahir wajib diisi.',
            'valid_date'  => 'Format tanggal lahir tidak valid.',
        ],
        'departemen' => [
            'max_length' => 'Departemen maksimal 100 karakter.',
        ],
        'alamat' => [
            'max_length' => 'Alamat maksimal 65535 karakter.',
        ],
        'kota' => [
            'max_length' => 'Kota maksimal 100 karakter.',
        ],
        'negara' => [
            'max_length' => 'Negara maksimal 100 karakter.',
        ],
        'nomer_telfon' => [
            'max_length' => 'Nomor telepon maksimal 20 karakter.',
        ],
        'status' => [
            'required' => 'Status wajib diisi.',
            'in_list'  => 'Status harus aktif atau nonaktif.',
        ],
    ];

    public function getKaryawanWithDepartemen($id_karyawan = null)
{
    $builder = $this->db->table($this->table);
    $builder->select('karyawan.*, departemen.nama_departemen');
    $builder->join('departemen', 'departemen.id_departemen = karyawan.departemen', 'left'); // Join tabel departemen
    if ($id_karyawan !== null) {
        $builder->where('karyawan.id_karyawan', $id_karyawan); // Filter berdasarkan ID karyawan
        return $builder->get()->getRowArray(); // Ambil satu baris hasil
    }
    return $builder->get()->getResultArray(); // Ambil semua data hasil
}

}