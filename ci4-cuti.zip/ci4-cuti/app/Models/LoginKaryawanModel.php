<?php

namespace App\Models;

use CodeIgniter\Model;

class LoginKaryawanModel extends Model
{
    protected $table = 'karyawan'; // Nama tabel
    protected $primaryKey = 'id_karyawan'; // Primary key
    protected $allowedFields = [
        'nama_awal', 'nama_akhir', 'email', 'password', 'jenis_kelamin', 
        'tanggal_lahir', 'departemen', 'alamat', 'kota', 'negara', 
        'nomer_telfon', 'status', 'tanggal_daftar'
    ];

    // Otomatis mengisi timestamp saat insert/update
    protected $useTimestamps = true;
    protected $createdField  = 'tanggal_daftar';
    protected $updatedField  = 'tanggal_update';

    // Hash password sebelum disimpan ke database
    public function beforeInsert(array $data)
    {
        if (isset($data['data']['password'])) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }
        return $data;
    }
}