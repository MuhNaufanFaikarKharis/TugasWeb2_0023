<!-- views/karyawan/rekappdf.php -->
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; }
        h1 { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Rekap Cuti Karyawan</h1>
    <p><strong>Nama Karyawan:</strong> <?= htmlspecialchars($karyawan['nama_awal'] . ' ' . $karyawan['nama_akhir']); ?></p>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Tipe Cuti</th>
                <th>Tanggal Mulai</th>
                <th>Tanggal Selesai</th>
                <th>Alasan</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            <?php foreach ($rekapCuti as $cuti) : ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($cuti['tipe_cuti']) ?></td>
                    <td><?= htmlspecialchars($cuti['tanggal_cuti']) ?></td>
                    <td><?= htmlspecialchars($cuti['tanggal_selesai_cuti']) ?></td>
                    <td><?= htmlspecialchars($cuti['alasan_cuti']) ?></td>
                    <td><?= ucfirst(htmlspecialchars($cuti['status'])) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
