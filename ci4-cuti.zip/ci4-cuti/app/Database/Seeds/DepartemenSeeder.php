<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DepartemenSeeder extends Seeder
{
    public function run()
    {
        $departemen = [
            [
                'nama_departemen' => 'HR',
                'singkatan_departemen' => 'HR', // Nama kolom diperbaiki
                'kode_departemen' => 'HR01',    // Nama kolom diperbaiki
                'tanggal_dibuat' => date('Y-m-d H:i:s'),
            ],
            [
                'nama_departemen' => 'IT',
                'singkatan_departemen' => 'IT', // Nama kolom diperbaiki
                'kode_departemen' => 'IT01',    // Nama kolom diperbaiki
                'tanggal_dibuat' => date('Y-m-d H:i:s'),
            ],
        ];

        $this->db->table('departemen')->insertBatch($departemen);
    }
}
