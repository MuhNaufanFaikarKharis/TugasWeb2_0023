<?php

namespace App\Models;

use CodeIgniter\Model;

class DashboardAdminModel extends Model
{
    protected $db;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
    }

    public function getTotalKaryawan()
    {
        return $this->db->table('karyawan')->countAll();
    }

    public function getTotalDepartemen()
    {
        return $this->db->table('departemen')->countAll();
    }

    public function getTotalTipeCuti()
    {
        return $this->db->table('cuti')->countAll();
    }

    public function getPengajuanCutiTerakhir()
    {
        return $this->db->table('detail_cuti')
            ->select('karyawan.nama_awal, karyawan.nama_akhir, detail_cuti.tipe_cuti, detail_cuti.tanggal_pengajuan, detail_cuti.status')
            ->join('karyawan', 'detail_cuti.id_karyawan = karyawan.id_karyawan')
            ->orderBy('detail_cuti.tanggal_pengajuan', 'DESC')
            ->limit(5)
            ->get()
            ->getResultArray();
    }
}
