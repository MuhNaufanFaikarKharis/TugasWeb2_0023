<html>
<head>
    <title>Laporan Cuti</title>
</head>
<body>
    <h1>Laporan Daftar Cuti</h1>
    <table border="1" cellpadding="5" cellspacing="0">
        <thead>
            <tr>
                <th>ID Cuti</th>
                <th>Nama Cuti</th>
                <th>Jumlah Hari</th>
                <th>Tanggal Pengajuan</th> <!-- Tambahkan kolom Tanggal Pengajuan -->
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            <?php foreach ($cuti as $item): ?>
                <tr>
                    <td><?= $item['id_cuti']; ?></td>
                    <td><?= $item['tipe_cuti']; ?></td>
                    <td><?= $item['tanggal_cuti']; ?> - <?= $item['tanggal_selesai_cuti']; ?></td>
                    <td><?= $item['tanggal_pengajuan']; ?></td> <!-- Tampilkan Tanggal Pengajuan -->
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
