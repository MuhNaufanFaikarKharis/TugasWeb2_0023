<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Departemen</title>
    <link href="<?= base_url('sb-admin2/vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet">
    <link href="<?= base_url('sb-admin2/css/sb-admin-2.min.css') ?>" rel="stylesheet">
</head>

<body class="bg-gradient-primary">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-5 col-lg-6 col-md-9">
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Tambah Departemen</h1>
                            </div>
                            <form action="<?= base_url('/departemen/store') ?>" method="post">
                                <?= csrf_field() ?>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="nama_departemen" placeholder="Nama Departemen" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="singkatan_departemen" placeholder="Singkatan Departemen" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="kode_departemen" placeholder="Kode Departemen" required>
                                </div>
                                <button type="submit" class="btn btn-primary btn-user btn-block">Simpan</button>
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="<?= base_url('/departemen') ?>">Kembali ke Daftar Departemen</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url('sb-admin2/vendor/jquery/jquery.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/js/sb-admin-2.min.js') ?>"></script>

</body>

</html>
