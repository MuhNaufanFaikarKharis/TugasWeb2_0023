<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'admin'; // Nama tabel database
    protected $primaryKey = 'id'; // Primary key
    protected $allowedFields = ['username', 'password', 'tanggal_dibuat', 'tanggal_diupdate']; // Kolom yang diizinkan untuk diakses

    /**
     * Fungsi untuk mencari pengguna berdasarkan username.
     *
     * @param string $username
     * @return array|null
     */
    public function getUserByUsername($username)
    {
        return $this->where('username', $username)->first();
    }
}
