<?php

namespace App\Models;

use CodeIgniter\Model;

class DetailCutiModel extends Model
{
    protected $table = 'detail_cuti';
    protected $primaryKey = 'id_detail_cuti';
    protected $allowedFields = [
        'id_karyawan', 'id_cuti', 'tanggal_cuti', 'tanggal_selesai_cuti',
        'alasan_cuti', 'tanggal_pengajuan', 'status', 'pesan_admin', 'tanggal_konfirmasi_admin'
    ];
}
