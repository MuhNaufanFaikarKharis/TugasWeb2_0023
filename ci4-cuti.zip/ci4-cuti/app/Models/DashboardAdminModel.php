<?php

namespace App\Models;

use CodeIgniter\Model;

class DashboardAdminModel extends Model
{
    protected $table = 'karyawan'; // Menggunakan nama tabel karyawan
    protected $primaryKey = 'id_karyawan'; // Pastikan menggunakan primary key yang benar
    protected $returnType = 'array';

    public function getTotalKaryawan()
    {
        return $this->countAll(); // Menghitung jumlah karyawan
    }

    public function getTotalDepartemen()
    {
        return $this->db->table('departemen')->countAll(); // Menghitung jumlah departemen
    }

    public function getTotalTipeCuti()
    {
        return $this->db->table('cuti')->countAll(); // Menghitung jumlah tipe cuti
    }

    public function getPengajuanCutiTerakhir()
    {
        $builder = $this->db->table('detail_cuti')
                            ->select('detail_cuti.*, karyawan.nama_awal, karyawan.nama_akhir, cuti.tipe_cuti')
                            ->join('karyawan', 'detail_cuti.id_karyawan = karyawan.id_karyawan')
                            ->join('cuti', 'detail_cuti.tipe_cuti = cuti.tipe_cuti')
                            ->orderBy('tanggal_pengajuan', 'DESC')
                            ->limit(5);
    
        return $builder->get()->getResultArray(); // Kembalikan hasil sebagai array
    }
}
