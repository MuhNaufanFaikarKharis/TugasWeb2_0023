<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class CutiSeeder extends Seeder
{
    public function run()
    {
        $cuti = [
            [
                'jenis_cuti'   => 'Annual Leave',
                'alasan_cuti'  => 'Vacation',
            ],
            [
                'jenis_cuti'   => 'Sick Leave',
                'alasan_cuti'  => 'Illness',
            ],
        ];

        $this->db->table('cuti')->insertBatch($cuti);
    }
}
