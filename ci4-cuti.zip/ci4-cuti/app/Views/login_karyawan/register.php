<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Karyawan</title>
    <link href="<?= base_url('sb-admin2/vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet">
    <link href="<?= base_url('sb-admin2/css/sb-admin-2.min.css') ?>" rel="stylesheet">
</head>

<body class="bg-gradient-primary">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-8 col-md-9">
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Registrasi Akun Karyawan</h1>
                            </div>
                            <!-- Menampilkan error dari flashdata -->
                            <?php if (session()->getFlashdata('error')): ?>
                                <div class="alert alert-danger">
                                    <?= session()->getFlashdata('error'); ?>
                                </div>
                            <?php endif; ?>
                            <form action="<?= base_url('/login_karyawan/register') ?>" method="post">
                                <?= csrf_field(); ?>
                                <!-- Nama Awal -->
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="nama_awal" placeholder="Nama Awal" value="<?= old('nama_awal') ?>" minlength="3" required>
                                </div>
                                <!-- Nama Akhir -->
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="nama_akhir" placeholder="Nama Akhir" value="<?= old('nama_akhir') ?>" minlength="3" required>
                                </div>
                                <!-- Email -->
                                <div class="form-group">
                                    <input type="email" class="form-control form-control-user" name="email" placeholder="Email" value="<?= old('email') ?>" required>
                                </div>
                                <!-- Password -->
                                <div class="form-group">
                                    <input type="password" class="form-control form-control-user" name="password" placeholder="Password (min. 6 karakter)" minlength="6" required>
                                </div>
                                <!-- Konfirmasi Password -->
                                <div class="form-group">
                                    <input type="password" class="form-control form-control-user" name="password_confirm" placeholder="Konfirmasi Password" minlength="6" required>
                                </div>
                                <!-- Jenis Kelamin -->
                                <div class="form-group">
                                    <select class="form-control" name="jenis_kelamin" required>
                                        <option value="" disabled selected>Jenis Kelamin</option>
                                        <option value="L">Laki-laki</option>
                                        <option value="P">Perempuan</option>
                                    </select>
                                </div>
                                <!-- Tanggal Lahir -->
                                <div class="form-group">
                                    <input type="date" class="form-control form-control-user" name="tanggal_lahir" value="<?= old('tanggal_lahir') ?>" required>
                                </div>
                                <!-- Departemen -->
                                <div class="form-group">
                                    <select class="form-control" name="departemen" required>
                                        <option value="" disabled selected>Pilih Departemen</option>
                                        <?php if (!empty($departemen)) : ?>
                                            <?php foreach ($departemen as $d) : ?>
                                                <option value="<?= $d['id_departemen'] ?>" <?= old('departemen') == $d['id_departemen'] ? 'selected' : '' ?>>
                                                    <?= $d['nama_departemen'] ?>
                                                </option>
                                            <?php endforeach; ?>
                                        <?php else : ?>
                                            <option value="">Tidak ada departemen tersedia</option>
                                        <?php endif; ?>
                                    </select>

                                </div>
                                <!-- Alamat -->
                                <div class="form-group">
                                    <textarea class="form-control" name="alamat" placeholder="Alamat" rows="3" required><?= old('alamat') ?></textarea>
                                </div>
                                <!-- Kota -->
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="kota" placeholder="Kota" value="<?= old('kota') ?>" required>
                                </div>
                                <!-- Negara -->
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="negara" placeholder="Negara" value="<?= old('negara') ?>" required>
                                </div>
                                <!-- Nomor Telepon -->
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="nomer_telfon" placeholder="Nomor Telepon" value="<?= old('nomer_telfon') ?>" required>
                                </div>
                                <!-- Tombol Submit -->
                                <button type="submit" class="btn btn-primary btn-user btn-block">Registrasi</button>
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="<?= base_url('/login_karyawan') ?>">Sudah punya akun? Login di sini</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url('sb-admin2/vendor/jquery/jquery.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/js/sb-admin-2.min.js') ?>"></script>

</body>

</html>