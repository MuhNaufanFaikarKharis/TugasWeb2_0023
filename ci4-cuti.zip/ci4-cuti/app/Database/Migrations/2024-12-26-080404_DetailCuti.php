<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class DetailCuti extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_detail_cuti' => [
                'type' => 'INT',
                'constraint' => 5,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'tipe_cuti' => [
                'type' => 'VARCHAR',
                'constraint' => '100',
                'null' => false,
            ],
            'tanggal_cuti' => [
                'type' => 'DATE',
                'null' => false,
            ],
            'tanggal_selesai_cuti' => [
                'type' => 'DATE',
                'null' => false,
            ],
            'alasan_cuti' => [
                'type' => 'TEXT',
                'null' => false,
            ],
            'tanggal_pengajuan' => [
                'type' => 'DATETIME',
                'null' => false,
            ],
            'pesan_admin' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'tanggal_konfirmasi_admin' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'status' => [
                'type' => 'ENUM',
                'constraint' => ['disetujui', 'ditolak', 'pending'],
                'null' => false,
            ],
            'telah_dibaca_admin' => [
                'type' => 'BOOLEAN',
                'default' => false,
            ],
        ]);

        $this->forge->addKey('id_detail_cuti', true);
        $this->forge->createTable('detail_cuti');
    }

    public function down()
    {
        $this->forge->dropTable('detail_cuti');
    }
}
