<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengajuan Cuti</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h3 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        .badge-success {
            background-color: #28a745;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
        }

        .badge-warning {
            background-color: #ffc107;
            color: black;
            padding: 2px 8px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <h3>Daftar Pengajuan Cuti</h3>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Karyawan</th>
                <th>Tipe Cuti</th>
                <th>Tanggal Pengajuan</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; foreach ($cuti as $c): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $c['nama_karyawan'] ?></td>
                    <td><?= $c['tipe_cuti'] ?></td>
                    <td><?= $c['tanggal_pengajuan'] ?></td>
                    <td>
                        <?php if ($c['status'] == 'disetujui'): ?>
                            <span class="badge-success">Disetujui</span>
                        <?php else: ?>
                            <span class="badge-warning">Menunggu</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
