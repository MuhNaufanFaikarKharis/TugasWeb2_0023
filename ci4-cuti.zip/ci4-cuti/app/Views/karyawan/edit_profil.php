<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil</title>
    <link href="<?= base_url('sb-admin2/vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet">
    <link href="<?= base_url('sb-admin2/css/sb-admin-2.min.css') ?>" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Sidebar -->
        <?= $this->include('karyawan/sidebar') ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Topbar -->
                <?= $this->include('karyawan/topbar') ?>

                <!-- Main Content -->
                <div class="container-fluid">
                    <h3 class="h3 mb-4 text-gray-800">Edit Profil</h3>
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <?php if (session()->getFlashdata('error')) : ?>
                                <div class="alert alert-danger">
                                    <?= session()->getFlashdata('error') ?>
                                </div>
                            <?php endif; ?>

                            <?php if (session()->getFlashdata('message')) : ?>
                                <div class="alert alert-success">
                                    <?= session()->getFlashdata('message') ?>
                                </div>
                            <?php endif; ?>

                            <?php if (session()->getFlashdata('validation')) : ?>
                                <div class="alert alert-danger">
                                    <?= session()->getFlashdata('validation')->listErrors() ?>
                                </div>
                            <?php endif; ?>

                            <form action="<?= base_url('/karyawan/updateProfil') ?>" method="post">
                                <?= csrf_field() ?>
                                <div class="form-group">
                                    <label for="nama_awal">Nama Awal</label>
                                    <input type="text" name="nama_awal" id="nama_awal" class="form-control" value="<?= old('nama_awal', $karyawan['nama_awal']) ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="nama_akhir">Nama Akhir</label>
                                    <input type="text" name="nama_akhir" id="nama_akhir" class="form-control" value="<?= old('nama_akhir', $karyawan['nama_akhir']) ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" name="email" id="email" class="form-control" value="<?= old('email', $karyawan['email']) ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="jenis_kelamin">Jenis Kelamin</label>
                                    <select name="jenis_kelamin" id="jenis_kelamin" class="form-control" required>
                                        <option value="L" <?= old('jenis_kelamin', $karyawan['jenis_kelamin']) === 'L' ? 'selected' : '' ?>>Laki-laki</option>
                                        <option value="P" <?= old('jenis_kelamin', $karyawan['jenis_kelamin']) === 'P' ? 'selected' : '' ?>>Perempuan</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="tanggal_lahir">Tanggal Lahir</label>
                                    <input type="date" name="tanggal_lahir" id="tanggal_lahir" class="form-control" value="<?= old('tanggal_lahir', $karyawan['tanggal_lahir']) ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="departemen">Departemen</label>
                                    <input type="text" name="departemen" id="departemen" class="form-control" value="<?= old('departemen', $karyawan['departemen']) ?>">
                                </div>
                                <div class="form-group">
                                    <label for="alamat">Alamat</label>
                                    <textarea name="alamat" id="alamat" rows="3" class="form-control"><?= old('alamat', $karyawan['alamat']) ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="kota">Kota</label>
                                    <input type="text" name="kota" id="kota" class="form-control" value="<?= old('kota', $karyawan['kota']) ?>">
                                </div>
                                <div class="form-group">
                                    <label for="negara">Negara</label>
                                    <input type="text" name="negara" id="negara" class="form-control" value="<?= old('negara', $karyawan['negara']) ?>">
                                </div>
                                <div class="form-group">
                                    <label for="nomer_telfon">Nomor Telepon</label>
                                    <input type="text" name="nomer_telfon" id="nomer_telfon" class="form-control" value="<?= old('nomer_telfon', $karyawan['nomer_telfon']) ?>">
                                </div>
                                <div class="form-group">
                                    <label for="status">Status</label>
                                    <select name="status" id="status" class="form-control" required>
                                        <option value="aktif" <?= old('status', $karyawan['status']) === 'aktif' ? 'selected' : '' ?>>Aktif</option>
                                        <option value="nonaktif" <?= old('status', $karyawan['status']) === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                <a href="<?= base_url('/karyawan/profil') ?>" class="btn btn-secondary">Batal</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url('sb-admin2/vendor/jquery/jquery.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/js/sb-admin-2.min.js') ?>"></script>
</body>

</html>