<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Departemen extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_departemen' => [
                'type' => 'INT',
                'constraint' => 5,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'nama_departemen' => [
                'type' => 'VARCHAR',
                'constraint' => '100',
                'null' => false,
            ],
            'singkatan_departemen' => [
                'type' => 'VARCHAR',
                'constraint' => '10',
                'null' => false,
            ],
            'kode_departemen' => [
                'type' => 'VARCHAR',
                'constraint' => '10',
                'null' => false,
            ],
            'tanggal_dibuat' => [
                'type' => 'DATETIME',
                'null' => false,
            ],
        ]);

        $this->forge->addKey('id_departemen', true);
        $this->forge->createTable('departemen');
    }

    public function down()
    {
        $this->forge->dropTable('departemen');
    }
}