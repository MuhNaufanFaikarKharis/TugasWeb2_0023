<?php

namespace App\Models;

use CodeIgniter\Model;

class KaryawanModel extends Model
{
    protected $table = 'karyawan';
    protected $primaryKey = 'id_karyawan';
    protected $allowedFields = [
        'nama_awal', 'nama_akhir', 'email', 'password', 'jenis_kelamin', 
        'tanggal_lahir', 'departemen', 'alamat', 'kota', 'negara', 
        'nomer_telfon', 'status', 'tanggal_daftar'
    ];
}
