<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\KaryawanModel;

class LoginController extends BaseController
{
    protected $userModel;
    protected $karyawanModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->karyawanModel = new KaryawanModel();  // Model untuk karyawan
    }

    // Login untuk Admin
    public function index()
    {
        return view('login_admin/login'); // Halaman login admin
    }

    // Login untuk Admin
    public function authenticateAdmin()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $user = $this->userModel->getUserByUsername($username);

        if ($user && password_verify($password, $user['password'])) {
            // Set session
            session()->set([
                'username' => $user['username'],
                'logged_in' => true,
            ]);
            return redirect()->to('/dashboard'); // Ganti dengan rute dashboard Anda
        }

        // Jika login gagal
        session()->setFlashdata('error', 'Username atau password salah.');
        return redirect()->to('/login');
    }

    // Login untuk Karyawan
    public function loginKaryawan()
    {
        return view('login_karyawan/login'); // Halaman login karyawan
    }

    // Autentikasi login Karyawan
    public function authenticateKaryawan()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $karyawan = $this->karyawanModel->where('email', $email)->first();

        if ($karyawan && password_verify($password, $karyawan['password'])) {
            // Set session untuk karyawan
            session()->set([
                'id_karyawan' => $karyawan['id_karyawan'],
                'email' => $karyawan['email'],
                'logged_in' => true,
            ]);
            return redirect()->to('/rekap-cuti'); // Ganti dengan rute dashboard karyawan Anda
        }

        // Jika login gagal
        session()->setFlashdata('error', 'Email atau password salah.');
        return redirect()->to('/login_karyawan');
    }

    // Logout untuk Admin dan Karyawan
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }

    // Halaman register untuk Admin
    public function register()
    {
        return view('login_admin/register'); // Halaman register admin
    }

    // Menyimpan data admin setelah registrasi
    public function storeAdmin()
    {
        $data = [
            'username' => $this->request->getPost('username'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
        ];

        $this->userModel->insert($data);
        return redirect()->to('/login')->with('success', 'Registrasi berhasil, silakan login.');
    }

    // Halaman register untuk Karyawan
    public function registerKaryawan()
    {
        $departemenModel = new \App\Models\DepartemenModel();

        // Ambil semua data departemen
        $data['departemen'] = $departemenModel->findAll();
        
        return view('login_karyawan/register', $data); // Halaman register karyawan
    }

    // Menyimpan data karyawan setelah registrasi
    public function storeKaryawan()
{
    $email = $this->request->getPost('email');
    $password = $this->request->getPost('password');
    
    if (!$email || !$password) {
        return redirect()->back()->with('error', 'Email dan password harus diisi.');
    }

    $data = [
        'nama_awal'     => $this->request->getPost('nama_awal'),
        'nama_akhir'    => $this->request->getPost('nama_akhir'),
        'email'         => $this->request->getPost('email'),
        'password'      => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
        'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
        'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
        'departemen'    => $this->request->getPost('departemen'),
        'alamat'        => $this->request->getPost('alamat'),
        'kota'          => $this->request->getPost('kota'),
        'negara'        => $this->request->getPost('negara'),
        'nomer_telfon'  => $this->request->getPost('nomer_telfon'),
        'status'        => 'aktif', // Misalnya diatur default aktif
        'tanggal_daftar'=> date('Y-m-d H:i:s'), // Default tanggal sekarang
    ];
    

    if ($this->karyawanModel->insert($data)) {
        return redirect()->to('/login_karyawan')->with('success', 'Registrasi berhasil, silakan login.');
    } else {
        return redirect()->back()->with('error', 'Gagal menyimpan data, silakan coba lagi.');
    }
}

}
