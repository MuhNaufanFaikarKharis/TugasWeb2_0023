<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil Karyawan</title>
    <link href="<?= base_url('sb-admin2/vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet">
    <link href="<?= base_url('sb-admin2/css/sb-admin-2.min.css') ?>" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Sidebar (sama seperti profil.php) -->
        <!-- Content Wrapper (sama seperti profil.php) -->

        <!-- Main Content -->
        <div class="container-fluid">
            <h3 class="h3 mb-4 text-gray-800">Edit Profil Karyawan</h3>
            <div class="card shadow mb-4">
                <div class="card-body">
                    <?php if (session()->getFlashdata('validation')) : ?>
                        <div class="alert alert-danger">
                            <?= session()->getFlashdata('validation')->listErrors() ?>
                        </div>
                    <?php endif; ?>
                    <form action="<?= base_url('/karyawan/updateProfil') ?>" method="post">
                        <?= csrf_field() ?>
                        <!-- Form fields untuk edit profil -->
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- End of Main Content -->
    </div>

    <script src="<?= base_url('sb-admin2/vendor/jquery/jquery.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/js/sb-admin-2.min.js') ?>"></script>
</body>

</html>