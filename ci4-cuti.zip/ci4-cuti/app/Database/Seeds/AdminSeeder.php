<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class AdminSeeder extends Seeder
{
    public function run()
    {
        //
        // Data yang akan dimasukkan ke dalam tabel users
        $data = [
            [
                'username' => 'admin',
                'password' => password_hash('admin123', PASSWORD_DEFAULT),
                'tanggal_dibuat' => date('Y-m-d H:i:s'),
                'tanggal_diupdate' => date('Y-m-d H:i:s'),
            ],
            [
                'username' => 'admin2',
                'password' => password_hash('admin', PASSWORD_DEFAULT),
                'tanggal_dibuat' => date('Y-m-d H:i:s'),
                'tanggal_diupdate' => date('Y-m-d H:i:s'),
            ],
            [
                'username' => 'naufanfk',
                'password' => password_hash('dzikirbareng', PASSWORD_DEFAULT),
                'tanggal_dibuat' => date('Y-m-d H:i:s'),
                'tanggal_diupdate' => date('Y-m-d H:i:s'),
            ],
        ];
        
        // Menyimpan data ke dalam tabel users
        $this->db->table('admin')->insertBatch($data);
    }
}
