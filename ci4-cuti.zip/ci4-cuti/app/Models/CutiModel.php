<?php

namespace App\Models;

use CodeIgniter\Model;

class CutiModel extends Model
{
    // Nama tabel di database
    protected $table = 'cuti';
    // Primary key dari tabel
    protected $primaryKey = 'id_cuti';
    // Kolom yang boleh diisi
    protected $allowedFields = ['tipe_cuti', 'tanggal_pengajuan', 'status'];

    // Mengambil semua data cuti
    public function getAllCuti()
    {
        return $this->findAll(); // Mengambil semua data dari tabel cuti
    }

    // Anda bisa menambahkan fungsi untuk mengambil data berdasarkan kondisi tertentu
    public function getCutiById($id)
     {
         return $this->find($id); // Mengambil cuti berdasarkan ID
     }
}
