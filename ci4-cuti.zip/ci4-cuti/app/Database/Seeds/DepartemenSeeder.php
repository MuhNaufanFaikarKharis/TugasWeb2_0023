<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DepartemenSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'nama_departemen' => 'Departemen Akuntansi',
                'singkatan_departemen' => 'DA',
                'kode_departemen' => 'DA1',
                'tanggal_dibuat' => date('Y-m-d H:i:s'),
            ],
            [
                'nama_departemen' => 'Departemen IT',
                'singkatan_departemen' => 'DIT',
                'kode_departemen' => 'IT1',
                'tanggal_dibuat' => date('Y-m-d H:i:s'),
            ],
            [
                'nama_departemen' => 'Departemen HRD',
                'singkatan_departemen' => 'HRD',
                'kode_departemen' => 'HRD1',
                'tanggal_dibuat' => date('Y-m-d H:i:s'),
            ],
        ];

        // Insert ke tabel `departemen`
        $this->db->table('departemen')->insertBatch($data);

        echo "Seeder selesai! Data departemen berhasil diinput.\n";
    }
}
