<?php

namespace App\Controllers;
use Dompdf\Dompdf; 
use Dompdf\Options;

use App\Models\CutiModel; // Memanggil model

class CutiController extends BaseController
{
    protected $cutiModel;

    // Konstruktor untuk memanggil model
    public function __construct()
    {
        $this->cutiModel = new CutiModel(); // Menginisialisasi model
    }

    // Menampilkan halaman daftar cuti
    public function index()
    {
        // Mengambil semua data cuti dari model
        $data['cuti'] = $this->cutiModel->getAllCuti();
        // Menampilkan data ke view 'cuti/index'
        return view('cuti/index', $data);
    }

    // Fungsi untuk mengekspor data ke PDF
    public function exportPdf()
{
    $cutiData = $this->cutiModel->getAllCuti(); // Mengambil data cuti

    // Menggunakan DOMPDF untuk membuat PDF
    $dompdf = new \Dompdf\Dompdf();
    $html = view('cuti/pdf', ['cuti' => $cutiData]); // Ambil view untuk PDF
    $dompdf->loadHtml($html);  // Memasukkan HTML ke DOMPDF
    $dompdf->setPaper('A4', 'landscape');  // Setting ukuran kertas
    $dompdf->render();  // Render PDF
    $dompdf->stream('daftar_cuti.pdf');  // Menampilkan file PDF
}

}
