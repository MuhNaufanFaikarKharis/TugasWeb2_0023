<h1>Detail Laporan Cuti</h1>
<p>Nama Karyawan: <?= $laporan['nama_karyawan']; ?></p>
<p>ID Karyawan: <?= $laporan['id_karyawan']; ?></p>
<p>Email: <?= $laporan['email']; ?></p>
<p>Nomor Handphone: <?= $laporan['nomor_handphone']; ?></p>
<p>Tipe Cuti: <?= $laporan['tipe_cuti']; ?></p>
<p>Alasan Cuti: <?= $laporan['alasan_cuti']; ?></p>
<p>Status: <?= $laporan['status_cuti']; ?></p>
<p>Tanggal Diajukan: <?= $laporan['tanggal_diajukan']; ?></p>
<p>Tanggal Konfirmasi: <?= $laporan['tanggal_konfirmasi']; ?></p>
<p>Pesan: <?= $laporan['pesan']; ?></p>
