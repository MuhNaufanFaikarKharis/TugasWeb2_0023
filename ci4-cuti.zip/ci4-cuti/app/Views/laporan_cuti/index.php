<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Laporan Cuti</title>
    <!-- SB Admin Bootstrap CSS -->
    <link href="<?= base_url('sb-admin2/vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?= base_url('sb-admin2/css/sb-admin-2.min.css') ?>" rel="stylesheet">
    <style>
        /* Add custom styles for the table */
        .table th,
        .table td {
            text-align: center;
        }

        .table thead {
            background-color: #4e73df;
            color: white;
        }

        .table-responsive {
            margin-top: 20px;
        }

        .table td,
        .table th {
            vertical-align: middle;
        }

        .btn-action {
            display: inline-block;
            visibility: visible !important;
        }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Admin</div>
            </a>

            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('dashboard') ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">Menu</div>

            <!-- Nav Item - Departemen -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('departemen') ?>">
                    <i class="fas fa-fw fa-building"></i>
                    <span>Departemen</span>
                </a>
            </li>

            <!-- Nav Item - Tipe Cuti -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('cuti') ?>">
                    <i class="fas fa-fw fa-calendar-alt"></i>
                    <span>Tipe Cuti</span>
                </a>
            </li>

            <!-- Nav Item - Manajemen Cuti -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('laporancuti') ?>">
                    <i class="fas fa-fw fa-tasks"></i>
                    <span>Manajemen Cuti</span>
                </a>
            </li>

            <hr class="sidebar-divider d-none d-md-block">

            <!-- Logout -->
            <li class="nav-item">
                <a class="nav-link" href="/logout">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url('dashboard') ?>">Dashboard</a>
                        </li>
                    </ul>
                </nav>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Daftar Laporan Cuti</h1>

                    <!-- Card untuk menampilkan data laporan cuti -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Laporan Cuti</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID Detail Cuti</th>
                                            <th>ID Karyawan</th>
                                            <th>ID Cuti</th>
                                            <th>Tipe Cuti</th>
                                            <th>Tanggal Cuti</th>
                                            <th>Tanggal Selesai Cuti</th>
                                            <th>Alasan Cuti</th>
                                            <th>Tanggal Pengajuan</th>
                                            <th>Pesan Admin</th>
                                            <th>Tanggal Konfirmasi Admin</th>
                                            <th>Status</th>
                                            <th>Telah Dibaca Admin</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($laporan as $item): ?>
                                            <tr>
                                                <td><?= $item['id_detail_cuti']; ?></td>
                                                <td><?= $item['id_karyawan']; ?></td>
                                                <td><?= $item['id_cuti']; ?></td>
                                                <td><?= $item['tipe_cuti']; ?></td>
                                                <td><?= $item['tanggal_cuti']; ?></td>
                                                <td><?= $item['tanggal_selesai_cuti']; ?></td>
                                                <td><?= $item['alasan_cuti']; ?></td>
                                                <td><?= $item['tanggal_pengajuan']; ?></td>
                                                <td><?= $item['pesan_admin']; ?></td>
                                                <td><?= $item['tanggal_konfirmasi_admin']; ?></td>
                                                <td><?= $item['status']; ?></td>
                                                <td><?= $item['telah_dibaca_admin'] ? 'Ya' : 'Tidak'; ?></td>
                                                <td>
                                                    <a href="<?= site_url('laporancuti/' . $item['id_detail_cuti']); ?>" class="btn btn-sm btn-info btn-action">Lihat Detail</a> |
                                                    <a href="<?= site_url('laporancuti/export-pdf/' . $item['id_detail_cuti']); ?>" class="btn btn-sm btn-success btn-action">Export ke PDF</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>

    <!-- SB Admin Bootstrap JS -->
    <script src="<?= base_url('sb-admin2/vendor/jquery/jquery.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/js/sb-admin-2.min.js') ?>"></script>

</body>

</html>