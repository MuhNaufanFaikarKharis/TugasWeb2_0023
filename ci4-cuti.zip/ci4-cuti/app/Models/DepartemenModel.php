<?php

namespace App\Models;

use CodeIgniter\Model;

class DepartemenModel extends Model
{
    protected $table = 'departemen'; // Nama tabel
    protected $primaryKey = 'id_departemen'; // Primary key tabel
    protected $allowedFields = ['nama_departemen', 'singkatan_departemen', 'kode_departemen', 'tanggal_dibuat']; // Kolom yang diizinkan untuk diisi
    protected $useTimestamps = false; // Tidak menggunakan fitur timestamp otomatis
}
