<?php

namespace App\Controllers;

use App\Models\LaporanCutiModel;
use CodeIgniter\Controller;

class LaporanCutiController extends Controller
{
    protected $laporanCutiModel;

    public function __construct()
    {
        $this->laporanCutiModel = new LaporanCutiModel();
    }

    public function index()
    {
        $data['laporan'] = $this->laporanCutiModel->findAll();
        return view('laporan_cuti/index', $data);
    }

    public function detail($id)
    {
        $data['laporan'] = $this->laporanCutiModel->find($id);
        if (!$data['laporan']) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data tidak ditemukan');
        }
        return view('laporan_cuti/detail', $data);
    }

    public function exportPdf($id)
    {
        $data['laporan'] = $this->laporanCutiModel->find($id);
        if (!$data['laporan']) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data tidak ditemukan');
        }

        // Menggunakan Dompdf untuk membuat file PDF
        $dompdf = new \Dompdf\Dompdf();
        $html = view('laporan_cuti/pdf', $data);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $dompdf->stream('Laporan_Cuti_' . $data['laporan']['nama_karyawan'] . '.pdf');
    }
}
