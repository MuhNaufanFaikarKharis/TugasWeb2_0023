<?php

namespace App\Models;

use CodeIgniter\Model;

class CutiModel extends Model
{
    protected $table = 'cuti';
    protected $primaryKey = 'id_cuti';
    protected $allowedFields = ['id_karyawan', 'id_cuti', 'tanggal_mulai', 'tanggal_selesai', 'alasan', 'status'];

    // Get all leave records
    public function getCuti()
{
    return $this->db->table('cuti')
        ->join('karyawan', 'cuti.id_karyawan = karyawan.id_karyawan') // Relasi dengan tabel karyawan
        ->join('tipe_cuti', 'cuti.id_cuti = tipe_cuti.id_cuti')       // Relasi dengan tabel tipe_cuti
        ->select('cuti.*, karyawan.nama_awal, karyawan.nama_akhir, tipe_cuti.tipe_cuti')
        ->get()->getResultArray();
}

}
