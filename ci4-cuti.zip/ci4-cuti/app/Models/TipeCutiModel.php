<?php

namespace App\Models;

use CodeIgniter\Model;

class TipeCutiModel extends Model
{
    protected $table = 'cuti';
    protected $primaryKey = 'id_cuti';
    protected $allowedFields = ['tipe_cuti', 'tanggal_dibuat'];
}
