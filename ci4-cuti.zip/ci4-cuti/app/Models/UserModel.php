<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'admin'; // Nama tabel di database
    protected $primaryKey = 'id'; // Primary key tabel

    protected $allowedFields = ['username', 'password', 'tanggal_dibuat', 'tanggal_diupdate'];

    // Aktifkan timestamps
    protected $useTimestamps = true;

    // Sesuaikan nama kolom timestamps
    protected $createdField = 'tanggal_dibuat';
    protected $updatedField = 'tanggal_diupdate';

    /**
     * Fungsi untuk mendaftarkan pengguna baru
     */
    public function registerUser($data)
    {
        return $this->insert($data);
    }

    /**
     * Ambil data pengguna berdasarkan username
     */
    public function getUserByUsername($username)
    {
        return $this->where('username', $username)->first();
    }
}
