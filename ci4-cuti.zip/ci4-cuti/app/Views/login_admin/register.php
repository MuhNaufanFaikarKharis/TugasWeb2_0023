<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="<?= base_url('sb-admin2/vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?= base_url('sb-admin2/css/sb-admin-2.min.css') ?>" rel="stylesheet">
</head>

<body class="bg-gradient-primary">

    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card o-hidden border-0 shadow-lg" style="width: 24rem; border-radius: 15px;">
            <div class="p-5">
                <div class="text-center mb-4">
                    <h1 class="h4 text-gray-900 fw-bold">Register</h1>
                </div>
                <?php if (session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
                <?php endif; ?>
                <form action="<?= base_url('/register/store') ?>" method="post">
                    <div class="form-group mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-user btn-block">Register</button>
                    <a href="<?= base_url('/register') ?>" class="btn btn-secondary btn-user btn-block">Login</a>
                    <div class="text-center">
                                <a class="small" href="<?= base_url('/') ?>">Sudah punya akun? Login di sini</a>
                            </div>
                 </form>
            </div>
        </div>
    </div>

</body>

</html>
