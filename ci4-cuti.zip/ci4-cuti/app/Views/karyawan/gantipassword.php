<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganti Password</title>
    <link href="<?= base_url('sb-admin2/vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet">
    <link href="<?= base_url('sb-admin2/css/sb-admin-2.min.css') ?>" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Sidebar -->
        <?= $this->include('karyawan/sidebar') ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Topbar -->
                <?= $this->include('karyawan/topbar') ?>

                <!-- Main Content -->
                <div class="container-fluid">
                    <h3 class="h3 mb-4 text-gray-800">Ganti Password</h3>
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <?php if (session()->getFlashdata('validation')) : ?>
                                <div class="alert alert-danger">
                                    <?= session()->getFlashdata('validation')->listErrors() ?>
                                </div>
                            <?php endif; ?>

                            <?php if (session()->getFlashdata('error')) : ?>
                                <div class="alert alert-danger">
                                    <?= session()->getFlashdata('error') ?>
                                </div>
                            <?php endif; ?>

                            <?php if (session()->getFlashdata('message')) : ?>
                                <div class="alert alert-success">
                                    <?= session()->getFlashdata('message') ?>
                                </div>
                            <?php endif; ?>

                            <form action="<?= base_url('/karyawan/updatePassword') ?>" method="post">
                                <?= csrf_field() ?>
                                <div class="form-group">
                                    <label for="password_lama">Password Lama</label>
                                    <input type="password" name="password_lama" id="password_lama" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="password_baru">Password Baru</label>
                                    <input type="password" name="password_baru" id="password_baru" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="konfirmasi_password">Konfirmasi Password Baru</label>
                                    <input type="password" name="konfirmasi_password" id="konfirmasi_password" class="form-control" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Ganti Password</button>
                                <a href="<?= base_url('/karyawan/profil') ?>" class="btn btn-secondary">Batal</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url('sb-admin2/vendor/jquery/jquery.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/js/sb-admin-2.min.js') ?>"></script>
</body>

</html>