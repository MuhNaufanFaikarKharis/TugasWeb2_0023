<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/login', 'LoginController::login'); // Menampilkan halaman login
$routes->post('/login', 'LoginController::loginProcess'); // Proses login
$routes->get('/logout', 'LoginController::logout'); // Logout pengguna

