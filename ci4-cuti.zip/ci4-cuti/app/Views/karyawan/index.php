<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- SB Admin Bootstrap CSS -->
    <link href="<?= base_url('sb-admin2/vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?= base_url('sb-admin2/css/sb-admin-2.min.css') ?>" rel="stylesheet">
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Admin</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="<?= base_url('dashboard') ?>"> <!-- Pastikan base_url() mengarah ke URL yang benar -->
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>


            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Menu
            </div>
            <!-- Nav Item - Departemen -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('departemen') ?>">
                    <i class="fas fa-fw fa-building"></i>
                    <span>Departemen</span>
                </a>
            </li>
            <!-- Nav Item - Tipe Cuti -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('cuti') ?>">
                    <i class="fas fa-fw fa-calendar-alt"></i>
                    <span>Tipe Cuti</span>
                </a>
            </li>


            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('karyawan') ?>">
                    <i class="fas fa-fw fa-users"></i>
                    <span>Karyawan</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('laporancuti') ?>">
                    <i class="fas fa-fw fa-tasks"></i>
                    <span>Manajemen Cuti</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Logout -->
            <li class="nav-item">
                <a class="nav-link" href="/logout">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
        <!-- End of Sidebar -->

        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <a href="<?= base_url('karyawan/create') ?>" class="btn btn-sm btn-primary">Tambah Karyawan</a>
                </nav>

                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Daftar Karyawan</h1>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Karyawan</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID Karyawan</th>
                                            <th>Nama Awal</th>
                                            <th>Nama Akhir</th>
                                            <th>Email</th>
                                            <th>Jenis Kelamin</th>
                                            <th>Tanggal Lahir</th>
                                            <th>Departemen</th>
                                            <th>Alamat</th>
                                            <th>Kota</th>
                                            <th>Negara</th>
                                            <th>Nomor Telepon</th>
                                            <th>Status</th>
                                            <th>Tanggal Daftar</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($karyawan as $item): ?>
                                            <tr>
                                                <td><?= $item['id_karyawan']; ?></td>
                                                <td><?= $item['nama_awal']; ?></td>
                                                <td><?= $item['nama_akhir']; ?></td>
                                                <td><?= $item['email']; ?></td>
                                                <td><?= $item['jenis_kelamin']; ?></td>
                                                <td><?= $item['tanggal_lahir']; ?></td>
                                                <td><?= $item['departemen']; ?></td>
                                                <td><?= $item['alamat']; ?></td>
                                                <td><?= $item['kota']; ?></td>
                                                <td><?= $item['negara']; ?></td>
                                                <td><?= $item['nomer_telfon']; ?></td>
                                                <td><?= $item['status']; ?></td>
                                                <td><?= $item['tanggal_daftar']; ?></td>
                                                <td>
                                                    <a href="<?= site_url('karyawan/edit/' . $item['id_karyawan']); ?>" class="btn btn-sm btn-info">Edit</a>
                                                    <a href="<?= site_url('karyawan/delete/' . $item['id_karyawan']); ?>" class="btn btn-sm btn-danger">Hapus</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>

    <!-- SB Admin Bootstrap JS -->
    <script src="<?= base_url('sb-admin2/vendor/jquery/jquery.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <script src="<?= base_url('sb-admin2/js/sb-admin-2.min.js') ?>"></script>
</body>

</html>