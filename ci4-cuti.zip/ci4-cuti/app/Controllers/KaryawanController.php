<?php

namespace App\Controllers;

use App\Models\KaryawanModel;

class KaryawanController extends BaseController
{
    protected $karyawanModel;

    public function __construct()
    {
        $this->karyawanModel = new KaryawanModel();
    }

    // Menampilkan daftar karyawan
    public function index()
    {
        $data['karyawan'] = $this->karyawanModel->findAll();
        return view('karyawan/index', $data);
    }

    // Menampilkan form tambah karyawan
    public function create()
    {
        return view('karyawan/create');
    }

    // Menyimpan data karyawan baru
    public function store()
    {
        $this->karyawanModel->save([
            'nama_awal' => $this->request->getPost('nama_awal'),
            'nama_akhir' => $this->request->getPost('nama_akhir'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'departemen' => $this->request->getPost('departemen'),
            'alamat' => $this->request->getPost('alamat'),
            'kota' => $this->request->getPost('kota'),
            'negara' => $this->request->getPost('negara'),
            'nomer_telfon' => $this->request->getPost('nomer_telfon'),
            'status' => $this->request->getPost('status'),
            'tanggal_daftar' => date('Y-m-d')
        ]);
        return redirect()->to('/karyawan');
    }

    // Menampilkan form edit karyawan
    public function edit($id)
    {
        $data['karyawan'] = $this->karyawanModel->find($id);
        return view('karyawan/edit', $data);
    }

    // Menyimpan perubahan data karyawan
    public function update($id)
    {
        $this->karyawanModel->update($id, [
            'nama_awal' => $this->request->getPost('nama_awal'),
            'nama_akhir' => $this->request->getPost('nama_akhir'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'departemen' => $this->request->getPost('departemen'),
            'alamat' => $this->request->getPost('alamat'),
            'kota' => $this->request->getPost('kota'),
            'negara' => $this->request->getPost('negara'),
            'nomer_telfon' => $this->request->getPost('nomer_telfon'),
            'status' => $this->request->getPost('status'),
            'tanggal_daftar' => $this->request->getPost('tanggal_daftar')
        ]);
        return redirect()->to('/karyawan');
    }

    // Menghapus data karyawan
    public function delete($id)
    {
        $this->karyawanModel->delete($id);
        return redirect()->to('/karyawan');
    }
}
