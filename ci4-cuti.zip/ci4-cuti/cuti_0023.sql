-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2025 at 03:45 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cuti_0023`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tanggal_dibuat` datetime NOT NULL,
  `tanggal_diupdate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `tanggal_dibuat`, `tanggal_diupdate`) VALUES
(1, 'admin', '$2y$10$/8PuI1bZzwFgrqrbP7i05ujmP89S77gl3um7jWimMjtvUt/UpjZhG', '2024-12-26 08:38:39', '2024-12-26 08:38:39'),
(2, 'admin2', '$2y$10$j55bDT0NBEAUUT2HOGeRTOpmBWC/XFiTaO0KTXMCLSr./1GB8rbCG', '2024-12-26 08:38:39', '2024-12-26 08:38:39'),
(3, 'admin', '$2y$10$CZ7NqhPSC/5OZqT331pwF.YTNB6cwJ5N50RzqDeVwgUH1egfTXIc.', '2024-12-26 09:28:27', '2024-12-26 09:28:27'),
(4, 'admin2', '$2y$10$hTTUf6xBckEfaqYhNkXN6.zpQ2jC1ltlc82ib5Foewia6DQozCIxS', '2024-12-26 09:28:27', '2024-12-26 09:28:27'),
(5, 'admin', '$2y$10$IFzKZy1FPx./4ZvgwaXNverHROYlK4cRP.nW54WNFNDKUr8n5bIHK', '2024-12-27 09:38:47', '2024-12-27 09:38:47'),
(6, 'admin2', '$2y$10$CDiz/52i9OOCGjKn96KhN.S4GCn39mo2QdEZ4BIODCfNAkeyEkHJu', '2024-12-27 09:38:47', '2024-12-27 09:38:47'),
(7, 'naufanfk', '$2y$10$922/NgFT76ET2OWyvz3EDOaxdVHn8tygiGTyQIkhONGC5LcVUTzc6', '2024-12-27 09:38:47', '2024-12-27 09:38:47'),
(8, 'naufanfk', '$2y$10$hQSV0UYOiNs1.qAUOB7llOA2Jk7NYjG5WSgigmtzFKBOsm2i0ahxO', '2025-01-04 08:29:33', '2025-01-04 08:29:33'),
(9, 'naufanfk', '$2y$10$eGQ4q9sZMaPUY9ho34x6rOxOz3VbZyQjcgw/DC2h11azWnBJgpcMa', '2025-01-04 08:30:02', '2025-01-04 08:30:02');

-- --------------------------------------------------------

--
-- Table structure for table `cuti`
--

CREATE TABLE `cuti` (
  `id_cuti` int(5) UNSIGNED NOT NULL,
  `tipe_cuti` varchar(100) NOT NULL,
  `tanggal_dibuat` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cuti`
--

INSERT INTO `cuti` (`id_cuti`, `tipe_cuti`, `tanggal_dibuat`) VALUES
(1, 'Cuti Sakit', '2025-01-04 07:20:08'),
(2, 'Cuti Melahirkan', '2025-01-04 07:20:08');

-- --------------------------------------------------------

--
-- Table structure for table `departemen`
--

CREATE TABLE `departemen` (
  `id_departemen` int(5) UNSIGNED NOT NULL,
  `nama_departemen` varchar(100) NOT NULL,
  `singkatan_departemen` varchar(10) NOT NULL,
  `kode_departemen` varchar(10) NOT NULL,
  `tanggal_dibuat` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departemen`
--

INSERT INTO `departemen` (`id_departemen`, `nama_departemen`, `singkatan_departemen`, `kode_departemen`, `tanggal_dibuat`) VALUES
(13, 'Departemen IT', 'DIT', 'IT1', '2025-01-15 19:24:33'),
(14, 'Departemen HRD', 'HRD', 'HRD1', '2025-01-15 19:24:33');

-- --------------------------------------------------------

--
-- Table structure for table `detail_cuti`
--

CREATE TABLE `detail_cuti` (
  `id_detail_cuti` int(5) UNSIGNED NOT NULL,
  `id_karyawan` int(5) UNSIGNED NOT NULL,
  `id_cuti` int(5) UNSIGNED DEFAULT NULL,
  `tipe_cuti` varchar(100) NOT NULL,
  `tanggal_cuti` date NOT NULL,
  `tanggal_selesai_cuti` date NOT NULL,
  `alasan_cuti` text NOT NULL,
  `tanggal_pengajuan` datetime NOT NULL,
  `pesan_admin` text DEFAULT NULL,
  `tanggal_konfirmasi_admin` datetime DEFAULT NULL,
  `status` enum('disetujui','ditolak','pending') NOT NULL,
  `telah_dibaca_admin` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_cuti`
--

INSERT INTO `detail_cuti` (`id_detail_cuti`, `id_karyawan`, `id_cuti`, `tipe_cuti`, `tanggal_cuti`, `tanggal_selesai_cuti`, `alasan_cuti`, `tanggal_pengajuan`, `pesan_admin`, `tanggal_konfirmasi_admin`, `status`, `telah_dibaca_admin`) VALUES
(2, 6, 2, 'Cuti Melahirkan', '2025-01-10', '2025-01-15', 'melahirkan', '2025-01-04 14:05:22', NULL, NULL, 'pending', 0),
(3, 6, 2, 'Cuti Melahirkan', '2025-01-22', '2025-01-24', 'capek pak\r\n', '2025-01-11 07:05:51', NULL, NULL, 'pending', 0),
(5, 6, 1, 'Cuti Sakit', '2025-01-15', '2025-01-24', 'di rawat di rumah sakit', '2025-01-15 15:06:00', NULL, NULL, 'pending', 0),
(6, 8, 1, 'Cuti Sakit', '2025-01-16', '2025-01-24', 'dirawat dirumah sakit\r\n', '2025-01-16 03:27:14', NULL, NULL, 'pending', 0),
(7, 8, 1, 'Cuti Sakit', '2025-01-16', '2025-01-24', 'dirawat dirumah sakit', '2025-01-16 05:17:18', NULL, NULL, 'pending', 0);

--
-- Triggers `detail_cuti`
--
DELIMITER $$
CREATE TRIGGER `before_insert_detail_cuti` BEFORE INSERT ON `detail_cuti` FOR EACH ROW BEGIN
  IF NEW.id_cuti IS NOT NULL THEN
    SET NEW.tipe_cuti = (SELECT tipe_cuti FROM cuti WHERE id_cuti = NEW.id_cuti);
  END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `id_karyawan` int(5) UNSIGNED NOT NULL,
  `nama_awal` varchar(100) NOT NULL,
  `nama_akhir` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `departemen` int(5) UNSIGNED DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `kota` varchar(100) DEFAULT NULL,
  `negara` varchar(100) DEFAULT NULL,
  `nomer_telfon` varchar(15) DEFAULT NULL,
  `status` enum('aktif','nonaktif') NOT NULL,
  `tanggal_daftar` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`id_karyawan`, `nama_awal`, `nama_akhir`, `email`, `password`, `jenis_kelamin`, `tanggal_lahir`, `departemen`, `alamat`, `kota`, `negara`, `nomer_telfon`, `status`, `tanggal_daftar`) VALUES
(6, 'Naufan Faikar', 'Kharis', 'muhammadnaufanfaikar@gmail.com', '$2y$10$0GNkAOgF3ecWWcKEAKAYGe.TCIIVkEDGU9CB41NNDabMgGpiID/42', 'L', '2024-12-17', NULL, 'dgdsfdfd', 'Pekalongan', 'Indonesia', '085601112010', 'aktif', '2024-12-30 04:59:15'),
(8, 'dimas ', 'kecil', 'dimaskecil@gmail.com', '$2y$10$2zdDpftzKio6rCKTsBT67u8uL0zkNeOAG3GE0JpEoVSl7VWpqY4Be', 'L', '2004-09-05', 14, 'jln kruing', 'Pekalongan', 'Indonesia', '085726472648', 'aktif', '2025-01-16 03:08:24');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(6, '2024-12-25-074134', 'App\\Database\\Migrations\\Admin', 'default', 'App', 1735200338, 1),
(7, '2024-12-26-074452', 'App\\Database\\Migrations\\Karyawan', 'default', 'App', 1735200338, 1),
(8, '2024-12-26-074515', 'App\\Database\\Migrations\\Departemen', 'default', 'App', 1735200338, 1),
(9, '2024-12-26-074548', 'App\\Database\\Migrations\\Cuti', 'default', 'App', 1735200338, 1),
(10, '2024-12-26-080404', 'App\\Database\\Migrations\\DetailCuti', 'default', 'App', 1735200338, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cuti`
--
ALTER TABLE `cuti`
  ADD PRIMARY KEY (`id_cuti`);

--
-- Indexes for table `departemen`
--
ALTER TABLE `departemen`
  ADD PRIMARY KEY (`id_departemen`);

--
-- Indexes for table `detail_cuti`
--
ALTER TABLE `detail_cuti`
  ADD PRIMARY KEY (`id_detail_cuti`),
  ADD KEY `fk_detail_cuti_karyawan` (`id_karyawan`),
  ADD KEY `id_cuti` (`id_cuti`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id_karyawan`),
  ADD KEY `fk_karyawan_departemen` (`departemen`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `cuti`
--
ALTER TABLE `cuti`
  MODIFY `id_cuti` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `departemen`
--
ALTER TABLE `departemen`
  MODIFY `id_departemen` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `detail_cuti`
--
ALTER TABLE `detail_cuti`
  MODIFY `id_detail_cuti` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `karyawan`
--
ALTER TABLE `karyawan`
  MODIFY `id_karyawan` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_cuti`
--
ALTER TABLE `detail_cuti`
  ADD CONSTRAINT `detail_cuti_ibfk_1` FOREIGN KEY (`id_cuti`) REFERENCES `cuti` (`id_cuti`),
  ADD CONSTRAINT `fk_detail_cuti_karyawan` FOREIGN KEY (`id_karyawan`) REFERENCES `karyawan` (`id_karyawan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD CONSTRAINT `fk_karyawan_departemen` FOREIGN KEY (`departemen`) REFERENCES `departemen` (`id_departemen`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
