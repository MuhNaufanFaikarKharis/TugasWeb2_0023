<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('/cuti/create') ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Karyawan</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">
    <!-- Menu Data Karyawan -->
    <li class="nav-item <?= uri_string() === 'karyawan' ? 'active' : '' ?>">
                <a class="nav-link" href="<?= base_url('/rekap-cuti') ?>">
                    <i class="fas fa-fw fa-users"></i>
                    <span>Data Karyawan</span>
                </a>
            </li>

    <!-- Menu Profil -->
    <li class="nav-item <?= uri_string() === 'karyawan/profil' ? 'active' : '' ?>">
        <a class="nav-link" href="<?= base_url('/karyawan/profil') ?>">
            <i class="fas fa-fw fa-user"></i>
            <span>Profil</span>
        </a>
    </li>
    <!-- Menu Cuti -->
    <li class="nav-item <?= uri_string() === 'cuti' || uri_string() === 'cuti/create' ? 'active' : '' ?>">
                <a class="nav-link" href="<?= base_url('/cuti/create') ?>">
                    <i class="fas fa-fw fa-calendar"></i>
                    <span>Cuti</span>
                </a>
            </li>

    <!-- Menu Logout -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('/logout') ?>">
            <i class="fas fa-fw fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">
</ul>