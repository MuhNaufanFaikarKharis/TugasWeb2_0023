<?php

namespace App\Controllers;

use App\Models\DashboardAdminModel;

class DashboardAdminController extends BaseController
{
    protected $dashboardModel;

    public function __construct()
    {
        $this->dashboardModel = new DashboardAdminModel();
    }

    public function index()
    {
        // Validasi login
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $data = [
            'totalKaryawan' => $this->dashboardModel->getTotalKaryawan(),
            'totalDepartemen' => $this->dashboardModel->getTotalDepartemen(),
            'totalTipeCuti' => $this->dashboardModel->getTotalTipeCuti(),
            'pengajuanCutiTerakhir' => $this->dashboardModel->getPengajuanCutiTerakhir(),
        ];

        return view('dashboard', $data);
    }
}
