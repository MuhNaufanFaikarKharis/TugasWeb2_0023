<!-- app/Views/laporan_cuti/pdf.php -->
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; }
        h1 { text-align: center; }
    </style>
</head>
<body>
    <h1>Laporan Cuti</h1>
    <p><strong>Nama Karyawan:</strong> <?= $laporan['nama_karyawan']; ?></p>
    <p><strong>Tipe Cuti:</strong> <?= $laporan['tipe_cuti']; ?></p>
    <p><strong>Tanggal Cuti:</strong> <?= $laporan['tanggal_cuti']; ?></p>
    <p><strong>Tanggal Selesai Cuti:</strong> <?= $laporan['tanggal_selesai_cuti']; ?></p>
    <p><strong>Alasan Cuti:</strong> <?= $laporan['alasan_cuti']; ?></p>
    <p><strong>Status:</strong> <?= $laporan['status']; ?></p>
</body>
</html>
