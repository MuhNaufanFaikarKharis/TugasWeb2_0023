<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Admin extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 5,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'username' => [
                'type' => 'VARCHAR',
                'constraint' => '100',
                'null' => false, // Kolom ini tidak boleh NULL
            ],
            'password' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => false, // Kolom ini tidak boleh NULL
            ],
            'tanggal_dibuat' => [
                'type' => 'DATETIME',
                'null' => false,
            ],
            'tanggal_diupdate' => [
                'type' => 'DATETIME',
                'null' => false,
            ],
        ]);

        $this->forge->addKey('id', true); // Menambahkan primary key
        $this->forge->createTable('admin'); // Membuat tabel "admin"
    }

    public function down()
    {
        $this->forge->dropTable('admin'); // Menghapus tabel "admin"
    }
}
