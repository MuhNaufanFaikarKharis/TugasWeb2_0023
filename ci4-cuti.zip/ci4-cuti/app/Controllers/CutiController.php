<?php

namespace App\Controllers;

use App\Models\KaryawanModel;
use App\Models\TipeCutiModel;
use App\Models\DetailCutiModel;
use App\Models\CutiModel;
use Dompdf\Dompdf;


class CutiController extends BaseController
{
    protected $karyawanModel;
    protected $tipeCutiModel;
    protected $detailCutiModel;
    

    public function __construct()
    {
        $this->karyawanModel = new KaryawanModel();
        $this->tipeCutiModel = new TipeCutiModel();
        $this->detailCutiModel = new DetailCutiModel();
    }

    /**
     * Menampilkan daftar pengajuan cuti.
     */
    public function index()
    {
        // Ambil data pengajuan cuti beserta data karyawan dan tipe cuti
        $data = [
            'title' => 'Daftar Pengajuan Cuti',
            'cuti' => $this->detailCutiModel
                ->select('detail_cuti.*, karyawan.nama_awal, karyawan.nama_akhir, cuti.tipe_cuti')
                ->join('karyawan', 'karyawan.id_karyawan = detail_cuti.id_karyawan')
                ->join('cuti', 'cuti.id_cuti = detail_cuti.id_cuti')
                ->findAll(),
        ];

        return view('cuti/index', $data);
    }

    /**
     * Menampilkan form untuk mengajukan cuti.
     */
    public function create()
    {
        // Periksa apakah session 'id_karyawan' ada
        if (!session()->has('id_karyawan')) {
            return redirect()->to('/login_karyawan')->with('error', 'Silakan login terlebih dahulu.');
        }

        // Ambil id_karyawan dari session
        $idKaryawan = session()->get('id_karyawan');

        // Ambil data karyawan yang sedang login
        $karyawan = $this->karyawanModel->find($idKaryawan);

        if (!$karyawan) {
            return redirect()->to('/login_karyawan')->with('error', 'Data karyawan tidak ditemukan.');
        }

        // Ambil data tipe cuti dari database
        $tipeCuti = $this->tipeCutiModel->findAll();

        // Kirim data ke view
        return view('cuti/create', [
            'karyawan' => $karyawan, // Data karyawan yang sedang login
            'tipe_cuti' => $tipeCuti // Data tipe cuti
        ]);
    }

    /**
     * Menyimpan pengajuan cuti baru.
     */
    public function store()
    {
        // Periksa apakah session 'id_karyawan' ada
        if (!session()->has('id_karyawan')) {
            return redirect()->to('/login_karyawan')->with('error', 'Silakan login terlebih dahulu.');
        }

        // Ambil id_karyawan dari session
        $idKaryawan = session()->get('id_karyawan');

        // Validasi input form
        $validation = \Config\Services::validation();
        if (!$this->validate([
            'id_cuti' => 'required',
            'tanggal_mulai' => 'required|valid_date',
            'tanggal_selesai' => 'required|valid_date',
            'alasan' => 'required',
        ])) {
            // Simpan pesan error validasi ke flashdata
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        // Validasi manual untuk tanggal
        $tanggal_mulai = $this->request->getPost('tanggal_mulai');
        $tanggal_selesai = $this->request->getPost('tanggal_selesai');

        if (strtotime($tanggal_selesai) < strtotime($tanggal_mulai)) {
            return redirect()->back()->withInput()->with('error', 'Tanggal selesai harus lebih besar atau sama dengan tanggal mulai.');
        }

        // Simpan data cuti
        $this->detailCutiModel->insert([
            'id_karyawan' => $idKaryawan, // Ambil dari session
            'id_cuti' => $this->request->getPost('id_cuti'),
            'tanggal_cuti' => $tanggal_mulai,
            'tanggal_selesai_cuti' => $tanggal_selesai,
            'alasan_cuti' => $this->request->getPost('alasan'),
            'tanggal_pengajuan' => date('Y-m-d H:i:s'),
            'status' => 'pending',
        ]);

        return redirect()->to('/cuti/create')->with('message', 'Pengajuan cuti berhasil.');
    }

    /**
     * Menampilkan form untuk menambah tipe cuti.
     */
    public function createTipeCuti()
    {
        $data = ['title' => 'Tambah Tipe Cuti'];
        return view('cuti/create_tipe_cuti', $data);
    }

    /**
     * Menyimpan tipe cuti baru.
     */
    public function storeTipeCuti()
    {
        // Validasi input form
        if (!$this->validate([
            'tipe_cuti' => 'required|max_length[100]',
        ])) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        // Simpan data tipe cuti
        $this->tipeCutiModel->save([
            'tipe_cuti' => $this->request->getPost('tipe_cuti'),
            'tanggal_dibuat' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to('/cuti')->with('message', 'Tipe cuti berhasil ditambahkan.');
    }

    public function exportPdf()
    {
        // Ambil data pengajuan cuti dari detail_cuti yang terhubung dengan cuti
        $data['cuti'] = $this->detailCutiModel
            ->select('detail_cuti.*, cuti.tipe_cuti, detail_cuti.tanggal_pengajuan') // Pastikan tanggal_pengajuan dari detail_cuti
            ->join('cuti', 'cuti.id_cuti = detail_cuti.id_cuti') // Join dengan tabel cuti
            ->findAll();
    
        // Load view untuk PDF
        $html = view('cuti/export-pdf', $data);
    
        // Generate PDF menggunakan Dompdf
        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
    
        // Kirimkan file PDF sebagai respons
        $dompdf->stream('laporan_cuti.pdf', ['Attachment' => false]);
    }
    
}