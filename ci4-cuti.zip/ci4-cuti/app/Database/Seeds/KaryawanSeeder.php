<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class KaryawanSeeder extends Seeder
{
    public function run()
    {
        // Data yang akan dimasukkan ke dalam tabel Karyawan
        $Karyawan = [
            [
                'nama_awal'     => 'John',
                'nama_akhir'    => 'Doe',
                'email'         => 'john.doe@example.com',
                'password'      => password_hash('password', PASSWORD_DEFAULT), // Hash password
                'jenis_kelamin' => 'Male',
                'tanggal_lahir' => '1990-01-01',
                'departemen'    => 1, // Assuming Department ID 1 exists
                'alamat'        => '123 Main St',
                'kota'          => 'Cityville',
                'negara'        => 'Countryland',
                'nomer_telfon'  => '1234567890',
                'status'        => 'Active',
                'tanggal_daftar'=> date('Y-m-d H:i:s'),
            ],
            [
                'nama_awal'     => 'Jane',
                'nama_akhir'    => 'Smith',
                'email'         => 'jane.smith@example.com',
                'password'      => password_hash('password', PASSWORD_DEFAULT), // Hash password
                'jenis_kelamin' => 'Female',
                'tanggal_lahir' => '1992-02-02',
                'departemen'    => 2, // Assuming Department ID 2 exists
                'alamat'        => '456 Elm St',
                'kota'          => 'Townsville',
                'negara'        => 'Countryland',
                'nomer_telfon'  => '0987654321',
                'status'        => 'Active',
                'tanggal_daftar'=> date('Y-m-d H:i:s'),
            ],
        ];

        // Insert data into the Karyawan table
        $this->db->table('Karyawan')->insertBatch($Karyawan);
    }
}
