<!-- app/Views/laporan_cuti/pdf.php -->
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; }
        h1 { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Laporan Cuti</h1>
    <table>
        <tr>
            <th>Nama Karyawan</th>
            <td><?= htmlspecialchars($laporan['nama_awal'] . ' ' . $laporan['nama_akhir']); ?></td>
        </tr>
        <tr>
            <th>Tipe Cuti</th>
            <td><?= htmlspecialchars($laporan['tipe_cuti']); ?></td>
        </tr>
        <tr>
            <th>Tanggal Mulai Cuti</th>
            <td><?= htmlspecialchars($laporan['tanggal_cuti']); ?></td>
        </tr>
        <tr>
            <th>Tanggal Selesai Cuti</th>
            <td><?= htmlspecialchars($laporan['tanggal_selesai_cuti']); ?></td>
        </tr>
        <tr>
            <th>Alasan Cuti</th>
            <td><?= htmlspecialchars($laporan['alasan_cuti']); ?></td>
        </tr>
        <tr>
            <th>Status</th>
            <td><?= ucfirst(htmlspecialchars($laporan['status'])); ?></td>
        </tr>
    </table>
</body>
</html>
