<?php

namespace App\Models;

use CodeIgniter\Model;

class LaporanCutiModel extends Model
{
    protected $table = 'detail_cuti'; // Nama tabel di database
    protected $primaryKey = 'id_detail_cuti'; // Primary key
    protected $allowedFields = [
        'id_detail_cuti',
        'id_karyawan',
        'id_cuti',
        'tipe_cuti',
        'tanggal_cuti',
        'tanggal_selesai_cuti',
        'alasan_cuti',
        'tanggal_pengajuan',
        'pesan_admin',
        'tanggal_konfirmasi_admin',
        'status',
        'telah_dibaca_admin'
    ];
}
