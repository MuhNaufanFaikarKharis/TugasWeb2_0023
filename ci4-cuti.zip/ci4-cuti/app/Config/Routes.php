<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->group('', ['namespace' => 'App\Controllers'], function($routes) {
    // Login
    $routes->get('/', 'LoginController::login'); // Halaman login
    $routes->post('/login', 'LoginController::loginProcess'); // Proses login
    $routes->get('/logout', 'LoginController::logout'); // Logout

    // Dashboard (validasi login manual dilakukan di controller)
    $routes->get('/dashboard', 'DashboardAdminController::index'); // Halaman dashboard


    $routes->get('/cuti', 'CutiController::index');
    $routes->get('/cuti/export-pdf', 'CutiController::exportPdf');



    $routes->get('/laporancuti', 'LaporanCutiController::index');
    $routes->get('/laporancuti/(:num)', 'LaporanCutiController::detail/$1');
    $routes->get('/laporancuti/export-pdf/(:num)', 'LaporanCutiController::exportPdf/$1');



    $routes->get('/karyawan', 'KaryawanController::index');
    $routes->get('/karyawan/create', 'KaryawanController::create');
    $routes->post('/karyawan/store', 'KaryawanController::store');
    $routes->get('/karyawan/edit/(:num)', 'KaryawanController::edit/$1');
    $routes->post('/karyawan/update/(:num)', 'KaryawanController::update/$1');
    $routes->get('/karyawan/delete/(:num)', 'KaryawanController::delete/$1');



    $routes->get('/departemen', 'DepartemenController::index');
    $routes->get('/departemen/create', 'DepartemenController::create');
    $routes->post('/departemen/store', 'DepartemenController::store');
    $routes->get('/departemen/edit/(:num)', 'DepartemenController::edit/$1');
    $routes->post('/departemen/update/(:num)', 'DepartemenController::update/$1');
    $routes->get('/departemen/delete/(:num)', 'DepartemenController::delete/$1');



    $routes->get('/login_karyawan', 'LoginKaryawanController::index'); // Login page
    $routes->get('/login_karyawan/register', 'LoginKaryawanController::registerPage'); // Registration page
    $routes->post('/login_karyawan/register', 'LoginKaryawanController::register'); // Handle registration submission
    $routes->post('/login_karyawan/doLogin', 'LoginKaryawanController::doLogin'); // Handle login submission
    $routes->get('/login_karyawan/logout', 'LoginKaryawanController::logout'); // Logout action
    






});
