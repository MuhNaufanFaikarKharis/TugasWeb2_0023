<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DetailCutiSeeder extends Seeder
{
    public function run()
    {
        $detailCuti = [
            [
                'id_user'       => 1,
                'jenis_cuti'    => 'Annual Leave',
                'tanggal_mulai' => '2023-12-01',
                'tanggal_selesai' => '2023-12-10',
                'alasan'        => 'Family vacation',
                'tanggal_permintaan' => date('Y-m-d H:i:s'),
                'pesan_admin'   => null,
                'tanggal_disetujui' => null,
                'status'        => 'pending',
                'diperiksa'     => false,
            ],
            [
                'id_user'       => 2,
                'jenis_cuti'    => 'Sick Leave',
                'tanggal_mulai' => '2023-11-15',
                'tanggal_selesai' => '2023-11-20',
                'alasan'        => 'Flu',
                'tanggal_permintaan' => date('Y-m-d H:i:s'),
                'pesan_admin'   => null,
                'tanggal_disetujui' => null,
                'status'        => 'pending',
                'diperiksa'     => false,
            ],
        ];

        $this->db->table('detail_cuti')->insertBatch($detailCuti);
    }
}
