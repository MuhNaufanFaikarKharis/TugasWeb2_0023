<?php

namespace App\Controllers;

use App\Models\DepartemenModel;

class DepartemenController extends BaseController
{
    protected $departemenModel;

    public function __construct()
    {
        $this->departemenModel = new DepartemenModel();
    }

    // Menampilkan daftar departemen
    public function index()
    {
        $data['departemen'] = $this->departemenModel->findAll();
        return view('departemen/index', $data);
    }

    // Menampilkan form tambah departemen
    public function create()
    {
        return view('departemen/create');
    }

    // Menyimpan data departemen baru
    public function store()
    {
        $this->departemenModel->save([
            'nama_departemen' => $this->request->getPost('nama_departemen'),
            'singkatan_departemen' => $this->request->getPost('singkatan_departemen'),
            'kode_departemen' => $this->request->getPost('kode_departemen'),
            'tanggal_dibuat' => date('Y-m-d H:i:s')  // otomatis menambahkan tanggal saat data dibuat
        ]);
        return redirect()->to('/departemen');
    }

    // Menampilkan form edit departemen
    public function edit($id)
    {
        $data['departemen'] = $this->departemenModel->find($id);
        return view('departemen/edit', $data);
    }

    // Menyimpan perubahan data departemen
    public function update($id)
    {
        $this->departemenModel->update($id, [
            'nama_departemen' => $this->request->getPost('nama_departemen'),
            'singkatan_departemen' => $this->request->getPost('singkatan_departemen'),
            'kode_departemen' => $this->request->getPost('kode_departemen'),
        ]);
        return redirect()->to('/departemen');
    }

    // Menghapus data departemen
    public function delete($id)
    {
        $this->departemenModel->delete($id);
        return redirect()->to('/departemen');
    }
}
